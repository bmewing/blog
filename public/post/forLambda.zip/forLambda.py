from __future__ import print_function

import json
import urllib
import boto3
import datetime
import tweepy
from titlecase import titlecase

now = datetime.datetime.now()

s3 = boto3.client('s3')


def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event and show its content type
    #bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.unquote_plus(event['Records'][0]['s3']['object']['key'].encode('utf8'))
    postDate = key[5:15]
    today = str(now.strftime("%Y-%m-%d"))
    if postDate == today:
        auth = tweepy.OAuthHandler('B5EGpEFf2L1lfRCKY0SsEH7c6','et1rST22a3iCGoxeHQIcAuEYtkpzbTy09WacAIv1brYPDviQIA')
        auth.set_access_token('20330237-K84AuP3aIsk0xWcuvhMz1QfWP4WcjGIDzxpLgFlGj','pBQXy3PttqU1v1qIHTFzO3zMHDFHUz1nq2VYTOYkzgOyt')
        api = tweepy.API(auth)
        postTitle = titlecase(key[16:][:-4].replace('-',' '))
        url = 'http://thug-r.life/'+key[:-4]+'/'
        
        post = 'I just wrote a post called "'+postTitle+'" at '+url
        print(post)
        api.update_status(post)
    else:
        print('Old post - ignore!')